
import './App.css';
import Card from './Components/Card';
import Navbar from './Components/Navbar';
import Priority from './Components/Priority';
import State from './Components/State';

function App() {
  return (
    <>
      <div id="main">

        <Navbar></Navbar>
        {/* <Priority></Priority> */}
        {/* <State></State> */}

      </div>
    </>
  );
}

export default App;
